/*
File:           quiz1-L1G.h
Purpose:        Definitions for submissible functions for CPSC259 in-lab quiz 1
                DO NOT CHANGE THIS FILE
Author:         gctien
Student Number: 12345678
CS Account:     a1a1a
Date:           September 19, 2020
*/

#ifndef _QUIZ1_L1G_H_
#define _QUIZ1_L1G_H_

double process(char* filename);

double get_average(int array[], int array_length);

#endif